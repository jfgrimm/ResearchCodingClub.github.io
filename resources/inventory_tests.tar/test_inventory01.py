from inventory import Item


def test_print_item():
    sword = Item("Sword", 8)
    assert "Sword" in str(sword)
    assert "size 8" in str(sword)

    falafel = Item("Falafel", 1)
    assert "Falafel" in str(falafel)
    assert "size 1" in str(falafel)
