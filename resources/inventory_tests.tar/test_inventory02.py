from inventory import Weapon, Food


class TestWeapon():
    def test_print(self):
        sword = Weapon("Sword", 8, 4)
        assert "Sword" in str(sword)
        assert "Weapon" in str(sword)
        assert "size 8" in str(sword)
        assert "power 4" in str(sword)

    def test_attack(self, capsys):
        sword = Weapon("Sword", 8, 4)
        sword.attack()
        captured = capsys.readouterr()
        assert "4 damage" in captured.out


class TestFood:
    def test_print(self):
        falafel = Food("Falafel", 1, 12)
        assert "Falafel" in str(falafel)
        assert "Food" in str(falafel)
        assert "size 1" in str(falafel)
        assert "potency 12" in str(falafel)

    def test_eat(self, capsys):
        falafel = Food("Falafel", 1, 12)
        falafel.eat()
        captured = capsys.readouterr()
        assert "12 health" in captured.out
        
