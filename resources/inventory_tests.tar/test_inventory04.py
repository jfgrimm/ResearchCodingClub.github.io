from inventory import Weapon, Food, Pack

import pytest


class TestWeapon():
    def test_print(self):
        sword = Weapon("Sword", 8, 4)
        assert "Sword" in str(sword)
        assert "Weapon" in str(sword)
        assert "size 8" in str(sword)
        assert "power 4" in str(sword)

    def test_attack(self, capsys):
        sword = Weapon("Sword", 8, 4)
        sword.attack()
        captured = capsys.readouterr()
        assert "4 damage" in captured.out


class TestFood:
    def test_print(self):
        falafel = Food("Falafel", 1, 12)
        assert "Falafel" in str(falafel)
        assert "Food" in str(falafel)
        assert "size 1" in str(falafel)
        assert "potency 12" in str(falafel)

    def test_eat(self, capsys):
        falafel = Food("Falafel", 1, 12)
        falafel.eat()
        captured = capsys.readouterr()
        assert "12 health" in captured.out


class TestPack:
    def test_print_empty(self):
        pack = Pack(10)
        assert "capacity of 10" in str(pack)
        assert "is empty" in str(pack)

        large_pack = Pack(20)
        assert "capacity of 20" in str(large_pack)
        assert "is empty" in str(large_pack)

    def test_is_empty(self):
        test_pack = Pack(10)
        assert test_pack.is_empty()

        falafel = Food("Falafel", 1, 12)
        test_pack.add(falafel)
        assert not test_pack.is_empty()

    def test_is_full(self):
        test_pack = Pack(10)
        assert not test_pack.is_full()

        huge_falafel = Food("Falafel", 10, 12)
        test_pack.add(huge_falafel)
        assert test_pack.is_full()

    def test_space_left(self):
        test_pack = Pack(10)
        assert test_pack.space_left() == 10

    def test_add(self):
        test_pack = Pack(10)
        assert test_pack.space_used() == 0

        falafel = Food("Falafel", 1, 12)
        test_pack.add(falafel)
        assert test_pack.space_used() == 1

        sword = Weapon("Sword", 8, 4)
        test_pack.add(sword)
        assert test_pack.space_used() == 9

    def test_add_not_an_item(self):
        test_pack = Pack(10)
        with pytest.raises(ValueError):
            test_pack.add("not an item")
            test_pack.add(42)

    def test_add_too_much(self):
        test_pack = Pack(0)
        falafel = Food("Falafel", 1, 12)
        with pytest.raises(ValueError):
            test_pack.add(falafel)

    def test_has_item(self):
        test_pack = Pack(10)
        falafel = Food("Falafel", 1, 12)
        sword = Weapon("Sword", 8, 4)
        test_pack.add(falafel)
        test_pack.add(sword)

        assert test_pack.has_item("Falafel")
        assert test_pack.has_item("Sword")
        assert not test_pack.has_item("Not there")
        assert not test_pack.has_item(0)

    def test_remove(self):
        test_pack = Pack(10)
        falafel = Food("Falafel", 1, 12)
        sword = Weapon("Sword", 8, 4)
        test_pack.add(falafel)
        test_pack.add(sword)

        got_falafel = test_pack.remove("Falafel")
        assert falafel.name == got_falafel.name
        assert falafel.size == got_falafel.size
        assert falafel.potency == got_falafel.potency

        got_sword = test_pack.remove("Sword")
        assert sword.name == got_sword.name
        assert sword.size == got_sword.size
        assert sword.power == got_sword.power

        with pytest.raises(ValueError):
            test_pack.remove("Not there")
